#include "util/ydhdfs.h"

int main(int argc, char** argv)
{
    if(argc != 3)
    {
        cout<<"Put a big file to HDFS as splits of 8 MB.\narg1: local path,    arg2: HDFS path"<<endl;
        return -1;
    }
    put(argv[1], argv[2]);
    return 0;
}
