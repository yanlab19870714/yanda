#ifndef TRIMMER_H_
#define TRIMMER_H_

template <class VertexT>
class Trimmer {
public:
	virtual void trim(VertexT & v) = 0;
};

#endif /* TRIMMER_H_ */
