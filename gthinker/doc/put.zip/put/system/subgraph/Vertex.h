#ifndef VERTEX_H_
#define VERTEX_H_

#include "util/serialization.h"
#include "util/ioser.h"

using namespace std;

//Default Hash Function =====================
template <class KeyT>
class DefaultHash {
public:
    inline int operator()(KeyT key)
    {
        if (key >= 0)
            return key % _num_workers;
        else
            return (-key) % _num_workers;
    }
};
//==========================================

template <class KeyT, class ValueT, class HashT = DefaultHash<KeyT> >
class Vertex {
public:
	KeyT id;
	ValueT value;

	typedef Vertex<KeyT, ValueT, HashT> VertexT;
	typedef KeyT KeyType;
	typedef ValueT ValueType;
	typedef HashT HashType;

	inline bool operator<(const VertexT& rhs) const
	{
		return id < rhs.id;
	}
	inline bool operator==(const VertexT& rhs) const
	{
		return id == rhs.id;
	}
	inline bool operator!=(const VertexT& rhs) const
	{
		return id != rhs.id;
	}

	friend ibinstream& operator<<(ibinstream& m, const VertexT& v)
	{
		m << v.id;
		m << v.value;
		return m;
	}

	friend obinstream& operator>>(obinstream& m, VertexT& v)
	{
		m >> v.id;
		m >> v.value;
		return m;
	}

	friend ifbinstream& operator<<(ifbinstream& m,  const VertexT& v)
	{
		m << v.id;
		m << v.value;
		return m;
	}

	friend ofbinstream& operator>>(ofbinstream& m,  VertexT& v)
	{
		m >> v.id;
		m >> v.value;
		return m;
	}
};

#endif
