#ifndef SUBG_H
#define SUBG_H

#include "subgraph/Vertex.h"
#include "subgraph/Task.h"
#include "subgraph/Comper.h"
#include "subgraph/Worker.h"

#endif
