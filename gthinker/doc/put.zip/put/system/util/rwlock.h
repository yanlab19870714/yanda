#ifndef RWLOCK_H
#define RWLOCK_H

#include <pthread.h>
#include <assert.h>
#include <stddef.h> //for NULL

class rwlock
{
	pthread_rwlock_t lock;

public:
    
	rwlock()
	{
		int ret = pthread_rwlock_init(&lock, NULL);
		assert(ret == 0);
	}

	~rwlock()
	{
		int ret = pthread_rwlock_destroy(&lock);
		assert(ret == 0);
	}

	void rdlock()
	{
		int ret = pthread_rwlock_rdlock(&lock);
		assert(ret == 0);
	}

	void wrlock()
	{
		int ret = pthread_rwlock_wrlock(&lock);
		assert(ret == 0);
	}

	void unlock()
	{
		int ret = pthread_rwlock_unlock(&lock);
		assert(ret == 0);
	}
};

#endif
