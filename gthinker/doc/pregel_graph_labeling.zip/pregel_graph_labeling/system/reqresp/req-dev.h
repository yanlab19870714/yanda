#ifndef REQ_DEV_H_
#define REQ_DEV_H_

#include "RMessageBuffer.h"
#include "RVertex.h"
#include "RWorker.h"
using namespace std;

#endif /* PREGEL_DEV_H_ */
