# dp-stats authors

This project is primarily maintained by researchers at the Department of Electrical and Computer Engineering at Rutgers, the State University of New Jersey.

## Primary authors

* [Sijie Xiong](https://gitlab.com/u/sx37)
* [Hafiz Imtiaz](https://gitlab.com/u/hafizimtiaz)

## Additional contributors

* [Anand D. Sarwate](https://gitlab.com/u/asarwate)
* [Liyang Xie](https://sites.google.com/site/xieliyang66/)
* [Dean Coco](https://gitlab.com/u/dacoco)


