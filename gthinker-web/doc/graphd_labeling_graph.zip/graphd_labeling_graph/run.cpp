#include "Vertex.h"
#include "Comper.h"
#include "Runner.h"
#include <cstdlib>
#include <ctime>

using namespace std;

char alphabet[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};

//input line format: vertexID \t numOfNeighbors neighbor1 neighbor2 ...
//output line format: v field(v) \t neighbor1 field(neighbor1) neighbor2 field(neighbor2) ...

bool DIRECTED = true;
typedef char Label;
//------

struct id_label
{
    VertexID id;
    Label l;
    
    id_label(){}
    
    id_label(VertexID id, Label l)
    {
        this->id = id;
        this->l = l;
    }
};

obinstream & operator<<(obinstream & m, const id_label & v)
{
    m << v.id;
    m << v.l;
    return m;
}

ibinstream & operator>>(ibinstream & m, id_label & v)
{
    m >> v.id;
    m >> v.l;
    return m;
}

ofbinstream & operator<<(ofbinstream & m, const id_label & v)
{
    m << v.id;
    m << v.l;
    return m;
}

ifbinstream & operator>>(ifbinstream & m, id_label & v)
{
    m >> v.id;
    m >> v.l;
    return m;
}

//====================================

class FieldVertex: public Vertex<VertexID, Label, id_label, id_label>
{
	public:
		virtual void compute(vector<id_label>& msgs, vector<id_label>& edges)
		{
			if (DIRECTED)
			{
				if (step_num() == 1)
				{
					// request
					for (int i = 0; i < edges.size(); i++)
					{
                        send_message(edges[i].id, id_label(id, '#')); //# is not useful, can be anything
					}
					vote_to_halt();
				}
				else if (step_num() == 2)
				{
					// respond
					for (int i = 0; i < msgs.size(); i++)
					{
						send_message(msgs[i].id, id_label(id, value));
					}
					vote_to_halt();
				}
				else
				{
					edges.clear();
					for (int i = 0; i < msgs.size(); i++)
					{
						edges.push_back(msgs[i]);
					}
					vote_to_halt();
				}
			}
			else
			{
				if (step_num() == 1)
				{
					// respond
					for (int i = 0; i < edges.size(); i++)
					{
						send_message(edges[i].id, id_label(id, value)); //# is not useful, can be anything
					}
					vote_to_halt();
				}
				else
				{
                    edges.clear();
                    for (int i = 0; i < msgs.size(); i++)
                    {
                        edges.push_back(msgs[i]);
                    }
                    vote_to_halt();
				}
			}
		}
};

class FieldComper:public Comper<FieldVertex>
{
    char buf[100];
    
public:
    FieldComper()
    {
        srand(time(NULL)); //use current time as seed for random generator
    }
    
    //C version
    virtual VertexID parseVertex(char* line, obinstream& file_stream)
    {
        char * pch = strtok(line, " \t");
        VertexID id = atoi(pch);
        file_stream << id; //write <I>
        int random = rand() % sizeof(alphabet);
        char label = alphabet[random]; //set v's label
        file_stream << label; //write <V>
        file_stream << true; //write <active>
        pch = strtok(NULL, " \t");
        int num = atoi(pch);
        file_stream << num; //write number of edges
        for (int i = 0; i < num; i++)
        {
            pch = strtok(NULL, " ");
            VertexID vid = atoi(pch);
            id_label tmp;
            tmp.id = vid;
            file_stream << tmp; //write attributes <E>
        }
        return id;
    }
    
    virtual void to_line(FieldVertex& v, vector<id_label>& edges, BufferedWriter& fout)
    {
        sprintf(buf, "%d %c\t", v.id, (char)(v.value));
        fout.write(buf);
        for (int i = 0; i < edges.size(); i++)
        {
            sprintf(buf, "%d %c ", edges[i].id, (char)(edges[i].l));
            fout.write(buf);
        }
        fout.write("\n");
    }
};

int main(int argc, char* argv[])
{
    Runner<FieldVertex, FieldComper> runner;
    string hdfs_inpath = argv[1];
    string hdfs_outpath = argv[2];
    string local_root = "graphd_local_disk_space";
    bool dump_with_edges = true;
    DIRECTED = true;
    runner.runHH(hdfs_inpath, hdfs_outpath, local_root, dump_with_edges, argc, argv); //HDFS Load, HDFS Dump
    return 0;
}
