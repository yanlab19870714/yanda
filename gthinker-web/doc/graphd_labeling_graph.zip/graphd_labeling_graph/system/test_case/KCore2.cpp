#include "Vertex.h"
#include "Comper.h"
#include "Runner.h"

using namespace std;

//input line format: vertexID \t count nbs1 nbs2 ...

#define CORE_NUMBER 3

class KCVertex:public Vertex<VertexID, bool, VertexID, VertexID> //no combiner, value = is current vertex deleted
{
    public:
    virtual void compute(vector<VertexID>& msgs, vector<VertexID>& edges)
    {
        //#### DEBUG BEGIN ####
		if (step_num()==1 && !value)
		{
			cout<<id<<": deleted = "<<value<<", edges = ";
			for(int i=0; i<edges.size(); i++) cout<<edges[i]<<" ";
			cout<<endl;
		}
		//#### DEBUG END ####
		//--------------------
        hash_set<VertexID> collector;
		for(int i=0; i<msgs.size(); i++)
		{
			collector.insert(msgs[i]);
		}
		vector<VertexID> newEdges;
		for(int i=0; i<edges.size(); i++){
			if(collector.find(edges[i]) == collector.end())
			{
				newEdges.push_back(edges[i]);
			}
		}
		
		if(newEdges.size() < CORE_NUMBER)
		{
			value = true;
			for(int i=0; i<newEdges.size(); i++) send_message(newEdges[i], id);
	    }
		edges.swap(newEdges);
		vote_to_halt();
    }
};

class KCComper:public Comper<KCVertex>
{
    char buf[100];
    
    public:
    virtual VertexID parseVertex(char* line, obinstream& file_stream)
    {
        char * pch = strtok(line, " \t");
        VertexID id = atoi(pch);
        file_stream << id; //write <I>
        file_stream << false; //write initial value
        file_stream << true; //write <active>
        int num = atoi(strtok(NULL, " "));
		file_stream << num; //write degree
        for (int i=0; i<num; i++)
		{
			VertexID nbID = atoll(strtok(NULL, " \t"));
            file_stream << nbID; //write nbs <E>
		}
        return id;
    }
    
    virtual void to_line(KCVertex& v, ofstream& fout)
    {
		if (v.value == false) fout<<v.id<<"\n"; //report vid if not deleted
    }
    
    virtual void to_line(KCVertex& v, BufferedWriter& fout)
    {
		if (v.value) return;
		sprintf(buf, "%d\t%d\n", v.id, v.degree); 
		fout.write(buf);
    }
};

int main(int argc, char* argv[])
{
    Runner<KCVertex, KCComper> runner;
    string hdfs_inpath = argv[1];
    string hdfs_outpath = argv[2];
    string local_root = "/localdata/hadoop/dfs/share/iopregel_yanda";
    bool dump_with_edges = false;
    runner.runLH(hdfs_outpath, local_root, dump_with_edges, argc, argv); //Local Load, HDFS Dump
    return 0;
}
