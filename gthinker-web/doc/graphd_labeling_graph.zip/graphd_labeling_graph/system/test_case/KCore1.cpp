#include "Vertex.h"
#include "Comper.h"
#include "Runner.h"

using namespace std;

//input line format: vertexID \t count nbs1 nbs2 ...

#define CORE_NUMBER 3

class KCVertex:public Vertex<VertexID, bool, VertexID, VertexID> //no combiner, value = is current vertex deleted
{
    public:
    virtual void compute(vector<VertexID>& msgs, vector<VertexID>& edges)
    {
        hash_set<VertexID> collector;
		for(int i=0; i<msgs.size(); i++)
		{
			collector.insert(msgs[i]);
		}
		vector<VertexID> newEdges;
		for(int i=0; i<edges.size(); i++){
			if(collector.find(edges[i]) == collector.end())
			{
				newEdges.push_back(edges[i]);
			}
		}
		if(newEdges.size() < CORE_NUMBER)
		{
			value = true;
			for(int i=0; i<newEdges.size(); i++) send_message(newEdges[i], id);
	    }
		edges.swap(newEdges);
		vote_to_halt();
    }
};

class KCComper:public Comper<KCVertex>
{
    char buf[100];
    
    public:
    virtual VertexID parseVertex(char* line, obinstream& file_stream)
    {
        char * pch = strtok(line, " \t");
        VertexID id = atoi(pch);
        file_stream << id; //write <I>
        file_stream << false; //write initial value
        file_stream << true; //write <active>
        int num = atoi(strtok(NULL, " "));
		file_stream << num; //write degree
        for (int i=0; i<num; i++)
		{
			VertexID nbID = atoll(strtok(NULL, " \t"));
            file_stream << nbID; //write nbs <E>
		}
        return id;
    }
    
    virtual void to_line(KCVertex& v, vector<VertexID>& edges, ofstream& fout)
    {
        if (v.value == false)
        {
            fout<<v.id<<" edges: ";
            for(VertexID & edge:edges) fout<<edge<<" ";
            fout<<"\n";
        }
    }
};

int main(int argc, char* argv[])
{
    Runner<KCVertex, KCComper> runner;
    string hdfs_inpath = argv[1];
    string hdfs_outpath = argv[2];
    string local_root = "/localdata/hadoop/dfs/share/iopregel_yanda";
	string local_outpath = local_root; ////Edited fot testing/////////////
    bool dump_with_edges = true;
    runner.runHL(hdfs_inpath, local_outpath, local_root, dump_with_edges, argc, argv); //HDFS Load, local Dump
    return 0;
}
